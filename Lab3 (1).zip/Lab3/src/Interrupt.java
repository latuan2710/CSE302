import java.util.concurrent.atomic.AtomicBoolean;

public class Interrupt {
	private AtomicBoolean isStop = new AtomicBoolean(false);
	private Thread interruptThread = null;
	
	public void interruptAfter(CPU cpu, int quantum) {
		Thread thread = new Thread() {
			@Override
			public void run() {
				/*
				try {
					Thread.sleep(quantum);
				} catch (InterruptedException e) {
				}
				
				
				long start = System.currentTimeMillis();
				long end = start + quantum;
				
				long current = start;
				while (current < end && Thread.interrupted() == false) {
					try {
						Thread.sleep(2);
					} catch (InterruptedException e) {
					}
					current = System.currentTimeMillis();
				}
				*/				
				
				long start = System.currentTimeMillis();
				long end = start + quantum;
				
				long current = start;
				while (current < end && Interrupt.this.isStop.get() == false) {
					Thread.yield();
					current = System.currentTimeMillis();
				}
				
				if (Interrupt.this.isStop.get() == false)
					cpu.interrupt();
			}
		};
		this.interruptThread = thread;
		thread.start();
	}
	
	public void stop() {
		if (this.isStop.get() == false) {
			this.isStop.set(true);
			if (this.interruptThread != null) {
				this.interruptThread.interrupt();
				try {
					this.interruptThread.join();
				} catch (InterruptedException e) {
				}
			}				
		}
	}
}

