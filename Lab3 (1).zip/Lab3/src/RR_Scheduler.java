import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class RR_Scheduler implements Scheduler {
	private CPU cpu = new CPU();
	private LinkedList<Task> readyQueue = new LinkedList<Task>();
	private int quantum;
	
	public RR_Scheduler(int quantum) {
		this.quantum = quantum;
	}

	@Override
	public List<ExecutionInfo> schedule(List<Task> tasks) {
		for (int i = 0; i < tasks.size(); i++)
			this.readyQueue.addLast(tasks.get(i));
		
		List<ExecutionInfo> result = new ArrayList<ExecutionInfo>();
		
		while (this.readyQueue.isEmpty() == false) {
			Task task = this.readyQueue.removeFirst();
			
			Interrupt interrupt = new Interrupt();
			interrupt.interruptAfter(this.cpu, this.quantum);						
			ExecutionInfo info = this.cpu.execute(task);	//CPU run
			interrupt.stop();
			
			// if task's burst > 0 -> add this task to end of the ready queue
			if (task.getBurst() > 0)
				this.readyQueue.addLast(task);
			
			result.add(info);			
		}
		
		return result;
	}

}