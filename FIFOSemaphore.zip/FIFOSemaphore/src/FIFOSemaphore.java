import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class FIFOSemaphore {
	private int permits;
	private Lock lock = new ReentrantLock();
	private List<Condition> conds = new LinkedList<>(); 
	
	public FIFOSemaphore(int p) {
		this.permits = p;
	}

	public void acquire() throws InterruptedException {
		this.lock.lock();
		try {
			if (this.permits > 0)
				this.permits--;
			else {
				Condition c = this.lock.newCondition();
				this.conds.add(c);
				c.await();
			}
		} finally {
			this.lock.unlock();
		}
	}
	
	public void release() {
		this.lock.lock();
		try {
			if (this.conds.size() > 0) {
				Condition c = this.conds.remove(0);
				c.signal();				
			} else 
				this.permits++;			
		} finally {
			this.lock.unlock();
		}
	}
}
