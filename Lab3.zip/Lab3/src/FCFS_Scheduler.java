import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class FCFS_Scheduler implements Scheduler {
	private CPU cpu = new CPU();
	private LinkedList<Task> readyQueue = new LinkedList<Task>();
	
	public FCFS_Scheduler() {		
	}
	
	@Override
	public List<ExecutionInfo> schedule(List<Task> tasks) {
		for (int i = 0; i < tasks.size(); i++)
			this.readyQueue.addLast(tasks.get(i));
		
		List<ExecutionInfo> result = new ArrayList<ExecutionInfo>();
		
		while (this.readyQueue.isEmpty() == false) {
			Task task = this.readyQueue.removeFirst();
			ExecutionInfo info = this.cpu.execute(task);			
			result.add(info);			
		}
		
		return result;
	}
}
