
public class CPU {

	public ExecutionInfo execute(Task task) {
		int burst = task.getBurst();
		long startTime = System.currentTimeMillis();
		long endTime = startTime + burst;
		
		long current = startTime;
		while (current < endTime) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
			}
			current = System.currentTimeMillis();
		}
				
		int duration = (int)(current - startTime);
		
		ExecutionInfo info = new ExecutionInfo(startTime, task, burst, duration);
		
		return info;
	}
}
