import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) throws IOException {
		if (args.length != 2) {
			System.out.println("Usage: java Main <algorith> <schedule.txt>");
			System.exit(0);
		}
		
		String algChoice = args[0].toUpperCase();
		BufferedReader inputFile = new BufferedReader(new FileReader(args[1]));
		
		List<Task> tasks = new ArrayList<>();
		String line;
		
		line = inputFile.readLine();
		while (line != null) {
			String[] params = line.split(",\\s*");
			Task task = new Task(params[0], Integer.parseInt(params[1]), Integer.parseInt(params[2]));
			tasks.add(task);
			
			line = inputFile.readLine();
		}
		inputFile.close();
		
		Scheduler scheduler = null;
		switch(algChoice) {
		case "FCFS":
			scheduler = new FCFS_Scheduler();
			break;
		case "SJF":
			scheduler = new SJF_Scheduler();
			break;
		case "PRI":
			scheduler = new PRI_Scheduler();
			break;		
		case "RR":
			scheduler = new RR_Scheduler();
			break;
		case "PRIRR":
			scheduler = new PRIRR_Scheduler();
			break;
		default:
			System.err.println("Invalid algorithm");
			System.exit(0);
		}			
		
		List<ExecutionInfo> result = scheduler.schedule(tasks);
		for (ExecutionInfo info : result) {
			System.out.println(info.getTime() + " : " + info.getTask().getName() + " - " + 
					+ info.getTask().getPriority() + " - " + info.getBurst() +
					" - " + info.getDuration());
		}
	}

}
