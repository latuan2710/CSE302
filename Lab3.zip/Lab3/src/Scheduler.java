import java.util.List;

public interface Scheduler {
	public List<ExecutionInfo> schedule(List<Task> tasks);
}

