import java.util.List;

public class PRI_Scheduler implements Scheduler {

	
	@Override
	public List<ExecutionInfo> schedule(List<Task> tasks) {
		// TODO Auto-generated method stub
		return null;
	}

}