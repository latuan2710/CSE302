import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class FIFOH2O {
	private Lock lock = new ReentrantLock();
	private List<Condition> hydrogenConds = new LinkedList<>();
	private List<Condition> oxygenConds = new LinkedList<>();
		
	public FIFOH2O() {		
	}
	
	public void hydrogen() throws InterruptedException {
		this.lock.lock();
		try {
			if (this.hydrogenConds.size() > 0 && this.oxygenConds.size() > 0) {
				Condition hydroC = this.hydrogenConds.remove(0);
				hydroC.signal();
				
				Condition oxyC = this.oxygenConds.remove(0);
				oxyC.signal();
			} else {
				Condition c = this.lock.newCondition();
				this.hydrogenConds.add(c);
				c.await();
			}			
		} finally {
			this.lock.unlock();
		}
	}
	
	public void oxygen() throws InterruptedException {
		this.lock.lock();
		try {
			if (this.hydrogenConds.size() > 1) {
				Condition hydroC = this.hydrogenConds.remove(0);
				hydroC.signal();
				
				hydroC = this.hydrogenConds.remove(0);
				hydroC.signal();
			} else {
				Condition c = this.lock.newCondition();
				this.oxygenConds.add(c);
				c.await();
			}
			
		} finally {
			this.lock.unlock();
		}
	}

}
