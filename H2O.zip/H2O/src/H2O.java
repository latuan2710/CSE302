import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class H2O {
	private Lock lock = new ReentrantLock();
	private int hydrogenCount = 0;
	private int oxygenCount = 0;
	private Condition hydrogenCond = this.lock.newCondition();
	private Condition oxygenCond = this.lock.newCondition();

	public H2O() {		
	}
	
	public void hydrogen() throws InterruptedException {
		this.lock.lock();
		try {
			if (this.hydrogenCount > 0 && this.oxygenCount > 0) {
				this.hydrogenCount--;
				this.oxygenCount--;
				this.hydrogenCond.signal();
				this.oxygenCond.signal();
			} else {
				this.hydrogenCount++;
				this.hydrogenCond.await();
			}
		} finally {
			this.lock.unlock();
		}
	}
	
	public void oxygen() throws InterruptedException {
		this.lock.lock();
		try {
			if (this.hydrogenCount > 1) {
				this.hydrogenCount -= 2;
				this.hydrogenCond.signal();
				this.hydrogenCond.signal();
			} else {
				this.oxygenCount++;
				this.oxygenCond.await();
			}			
		} finally {
			this.lock.unlock();
		}
	}
}
