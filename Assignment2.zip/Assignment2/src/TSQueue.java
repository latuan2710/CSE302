import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class TSQueue {
	private LinkedList<Integer> list = new LinkedList<>();
	private Lock lock = new ReentrantLock();
	
	public TSQueue() {		
	}
	
	public void addLast(int v) {
		this.lock.lock();
		try {
			
			this.list.add(v);
			
		} finally {
			this.lock.unlock();
		}
	}
	
	public int removeFirst() throws NoSuchElementException {
		this.lock.lock();
		try {
			
			return this.list.remove();
			
		} finally {
			this.lock.unlock();
		}		
	}
}
