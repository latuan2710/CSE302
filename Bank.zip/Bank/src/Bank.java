import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;

public class Bank {
	private ArrayList<Account> accounts = new ArrayList<>();
	
	public Bank(int accountNum, int balance) {
		for(int i = 0; i < accountNum; i++) {
			Account acc = new Account(i, balance);
			this.accounts.add(acc);
		}
	}
		
	private Account find(int id) {
		for(int i = 0; i < this.accounts.size(); i++)
			if(this.accounts.get(i).getId() == id)
				return this.accounts.get(i);
		return null;
	}
	
	public boolean transaction(int fromId, int toId, double amount) {
		Account from = this.find(fromId);
		if(from == null)
			return false;
		Account to = this.find(toId);
		if(to == null)
			return false;
		return this.transaction(from, to, amount);
	}
	
	private boolean transaction(Account from, Account to, double amout) {
		if(from.getBalance() < amout)
			return false;
		ReentrantLock fromLock = from.getLock();
		ReentrantLock toLock = to.getLock();
		
		if(System.identityHashCode(fromLock) < System.identityHashCode(toLock)) {
			fromLock.lock();
			toLock.lock();
			
			from.setBalance(from.getBalance() - amout);
			to.setBalance(to.getBalance() + amout);
			
			toLock.unlock();
			fromLock.unlock();			
		}
		else {
			toLock.lock();
			fromLock.lock();
						
			from.setBalance(from.getBalance() - amout);
			to.setBalance(to.getBalance() + amout);
			
			fromLock.unlock();
			toLock.unlock();
		}
		return true;		
	}
}
