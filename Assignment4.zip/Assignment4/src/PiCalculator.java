import java.util.Random;

public class PiCalculator extends Thread {
	private long pointCount;	// Points belong to circle
	private long pointNum;		// Total points
	
	public PiCalculator(long num) {
		this.pointCount = 0;
		this.pointNum = num;
	}
	
	@Override
	public void run() {
		this.calculate();
	}
	
	//calculate pi
	public void calculate() {
		Random xrandom =  new Random();
		Random yrandom =  new Random();
		
		double x, y;
		for (long i = 0; i < this.pointNum; i++) {
			x = xrandom.nextDouble() * 2 - 1;
			y = yrandom.nextDouble() * 2 - 1;
				
			if (x * x + y * y <= 1)
				this.pointCount++;
		}
	}
	
	public double pi() {
		double pi;
		pi = 4.0 * this.pointCount / this.pointNum;
		return pi;
	}

	public long getPointCount() {
		return pointCount;
	}

	public long getPointNum() {
		return pointNum;
	}
}
