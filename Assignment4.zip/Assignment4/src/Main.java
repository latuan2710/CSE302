
public class Main {

	public static void main(String[] args) {
		long n = 10000000000L;
		
		PiCalculator cal1 = new PiCalculator(n);
		PiCalculator cal2 = new PiCalculator(n);
		PiCalculator cal3 = new PiCalculator(n);
		PiCalculator cal4 = new PiCalculator(n);
		
		cal1.start();
		cal2.start();
		cal3.start();
		cal4.start();
		
		try {
			cal1.join();
		} catch (InterruptedException e) {
		}
		
		try {
			cal2.join();
		} catch (InterruptedException e) {
		}
		
		try {
			cal3.join();
		} catch (InterruptedException e) {
		}
		
		try {
			cal4.join();
		} catch (InterruptedException e) {
		}
		
		long totalPointsInCircle = cal1.getPointCount() + cal2.getPointCount() + 
				cal3.getPointCount() + cal4.getPointCount();
		long totalPoints = cal1.getPointNum() + cal2.getPointNum() + 
				cal3.getPointNum() + cal4.getPointNum();
		
		double pi = 4.0 * totalPointsInCircle / totalPoints;
		
		System.out.println(pi);
		
	}

}


