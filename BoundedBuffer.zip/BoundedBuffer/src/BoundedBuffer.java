import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedBuffer {
	private int[] buffer;
	private int count = 0;
	private int addIndex = 0;
	private int removeIndex = 0;
	
	private Lock lock = new ReentrantLock();
	private Condition fullCond = this.lock.newCondition();
	private Condition emptyCond = this.lock.newCondition();
	
	public BoundedBuffer(int size) {
		this.buffer = new int[size];
	}
	
	public void add(int v) throws InterruptedException {
		this.lock.lock();
		try {
			while (this.count == this.buffer.length)	//buffer is full
				this.fullCond.await();
			
			this.buffer[this.addIndex] = v;
			this.addIndex++;
			if (this.addIndex == this.buffer.length)
				this.addIndex = 0;
			//this.addIndex = (this.addIndex + 1) % this.buffer.length;
			this.count++;
			this.emptyCond.signal();			
		} finally {
			this.lock.unlock();
		}
	}
	
	public int remove() throws InterruptedException {
		this.lock.lock();
		try {
			while (this.count == 0)	//buffer is empty
				this.emptyCond.await();
			int value = this.buffer[this.removeIndex];
			this.removeIndex++;
			if (this.removeIndex == this.buffer.length)
				this.removeIndex = 0;
			//this.removeIndex = (this.removeIndex + 1) % this.buffer.length;
			this.count--;
			this.fullCond.signal();
			return value;			
		} finally {
			this.lock.unlock();
		}
	}
}
