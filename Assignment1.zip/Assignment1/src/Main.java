
public class Main {

	public static void main(String[] args) {
		SharedData data = new SharedData(0);
		
		int times = 1000000;
		
		IncreaseRunnable increase = new IncreaseRunnable(data, times);
		DecreaseRunnable decrease = new DecreaseRunnable(data, times);
		
		Thread t1 = new Thread(increase);
		t1.start();		
		try {
			t1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		Thread t2 = new Thread(decrease);
		t2.start();		
		try {
			t2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("End: Shared Data = " + data.getValue());
	}

}

class SharedData {
	private int value;
	
	public SharedData(int v) {
		this.value = v;
	}
	
	public int getValue() {
		return this.value;
	}
	
	public void setValue(int v) {
		this.value = v;
	}
}

class IncreaseRunnable implements Runnable {
	private SharedData data;
	private int times;
	
	public IncreaseRunnable(SharedData d, int t) {
		this.data = d;
		this.times = t;
	}
	
	@Override
	public void run() {
		for (int i = 0; i < this.times; i++) {
			int v = this.data.getValue();
			v = v + 1;
			this.data.setValue(v);
		}					
	}
}

class DecreaseRunnable implements Runnable {
	private SharedData data;
	private int times;
	
	public DecreaseRunnable(SharedData d, int t) {
		this.data = d;
		this.times = t;
	}
	
	@Override
	public void run() {
		for (int i = 0; i < this.times; i++) {
			int v = this.data.getValue();
			v = v - 1;
			this.data.setValue(v);
		}					
	}
}
