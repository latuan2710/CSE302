import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class OldBridge {
	private Lock lock = new ReentrantLock(true);
	private Condition dir0Cond = this.lock.newCondition();
	private Condition dir1Cond = this.lock.newCondition();
	private int dir0Count = 0;
	private int dir1Count = 0;
	
	private List<String> history = new ArrayList<>();
	
	public OldBridge() {		
	}

	public void arriveBridge(int dir) throws InterruptedException {
		this.lock.lock();
		try {
			String msg;
			if (dir == 0) {
				while (this.dir0Count == 3 || this.dir1Count > 0)
					this.dir0Cond.await();	
				this.dir0Count++;
				
				msg = Thread.currentThread().getName() + ": On bridge, dir 0, " + this.dir0Count;
				this.history.add(msg);
			} else {
				while (this.dir1Count == 3 || this.dir0Count > 0)
					this.dir1Cond.await();
				this.dir1Count++;
				
				msg = Thread.currentThread().getName() + ": On bridge, dir 1, " + this.dir1Count;
				this.history.add(msg);
			}
		} finally {
			this.lock.unlock();
		}
	}
	
	public void exitBridge(int dir) {
		this.lock.lock();
		try {
			String msg;
			if (dir == 0) {
				this.dir0Count--;
				this.dir0Cond.signal();
				this.dir1Cond.signal();	
				
				msg = Thread.currentThread().getName() + ": Exit bridge, dir 0, " + this.dir0Count;
				this.history.add(msg);
			} else {
				this.dir1Count--;
				this.dir1Cond.signal();
				this.dir0Cond.signal();	
				
				msg = Thread.currentThread().getName() + ": Exit bridge, dir 1, " + this.dir1Count;
				this.history.add(msg);
			}
		} finally {
			this.lock.unlock();
		}
	}

	public List<String> getHistory() {
		return history;
	}
}
