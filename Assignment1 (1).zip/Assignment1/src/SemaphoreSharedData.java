import java.util.concurrent.Semaphore;

public class SemaphoreSharedData implements SharedData {
	private int value;
	private Semaphore semaphore = new Semaphore(1);
	
	public SemaphoreSharedData(int v) {
		this.value = v;
	}
	
	@Override
	public void increase() throws InterruptedException {
		this.semaphore.acquire();
		
		this.value++;
		
		this.semaphore.release();
	}
	
	@Override
	public void decrease() throws InterruptedException {
		this.semaphore.acquire();
		
		this.value--;
		
		this.semaphore.release();
	}

	@Override
	public int getValue() {
		return value;
	}
}
