
public class SynchronizedSharedData implements SharedData {
	private int value;
	
	public SynchronizedSharedData(int v) {
		this.value = v;
	}
	
	@Override
	public synchronized void increase() {
		this.value++;		
	}
	
	@Override
	public synchronized void decrease() {
		this.value--;		
	}

	@Override
	public int getValue() {
		return value;
	}
}
