
public class Main {

	public static void main(String[] args) throws InterruptedException {
		SharedData data = new SemaphoreSharedData(0);
		int times = 10000000;
		
		System.out.println("Begin: " + data.getValue());
		
		IncreaseThread t1 = new IncreaseThread(data, times);
		
		DecreaseThread t2 = new DecreaseThread(data, times);

		t1.start();
		t2.start();
		
		t1.join();
		t2.join();
		
		System.out.println("End: " + data.getValue());
	}

}

class IncreaseThread extends Thread {
	private SharedData data;
	private int times;
	
	public IncreaseThread(SharedData data, int times) {
		this.data = data;
		this.times = times;
	}
	
	@Override
	public void run() {
		for (int i = 0; i < this.times; i++)
			try {
				this.data.increase();
			} catch (InterruptedException e) {
			}
	}
}

class DecreaseThread extends Thread {
	private SharedData data;
	private int times;
	
	public DecreaseThread(SharedData data, int times) {
		this.data = data;
		this.times = times;
	}
	
	@Override
	public void run() {
		for (int i = 0; i < this.times; i++)
			try {
				this.data.decrease();
			} catch (InterruptedException e) {
			}
	}
}
