import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class LockSharedData implements SharedData {
	private int value;
	
	private ReentrantLock lock = new ReentrantLock();
	
	public LockSharedData(int v) {
		this.value = v;
	}
	
	@Override
	public void increase() {
		this.lock.lock();
		try {
			
			this.value++;	
			
		} finally {
			this.lock.unlock();	
		}
	}
	
	@Override
	public void decrease() {
		this.lock.lock();
		try {
			
			this.value--;	
			
		} finally {
			this.lock.unlock();	
		}
	}

	@Override
	public int getValue() {
		return value;
	}
}

