
public interface SharedData {
	public void increase() throws InterruptedException;
	public void decrease() throws InterruptedException;
	public int getValue();
}
